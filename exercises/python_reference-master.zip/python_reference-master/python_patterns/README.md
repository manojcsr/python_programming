# A collection of useful Python snippets

[View](http://nbviewer.ipython.org/github/rasbt/python_reference/blob/master/python_patterns/patterns.ipynb) the IPython Notebook.