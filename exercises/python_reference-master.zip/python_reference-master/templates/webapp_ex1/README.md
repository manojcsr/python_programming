Sebastian Raschka, 2015

# Flask Example App 1

A simple Flask app that calculates the sum of two numbers entered in the respective input fields.

A more detailed description is going to follow some time in future.

You can run the app locally by executing `python app.py` within this directory.

<hr>

![](./img/img_1.png)
